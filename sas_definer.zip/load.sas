filename PADAB352 list;

 %put NOTE- ;
 %put NOTE: Loading package sas_definer, version 0.1.0, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-10-21T09:43:00; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Run %nrstr(%%)helpPackage(sas_definer) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_; 
 if NOT ("*"=symget("cherryPick")) then do; 
  put "NOTE- "; 
  put "NOTE: *** Cherry Picking ***"; 
  put "NOTE- Cherry Picking in action!! Be advised that"; 
  put "NOTE- dependencies/required packages will not be loaded!"; 
  put "NOTE- "; 
 end; 
run; 
%include  PADAB352(packagemetadata.sas) / nosource2; 

 data _null_;                                    
  call symputX("packageRequiredErrors", 0, "L"); 
 run;                                            
 %put NOTE- *Testing required SAS components*%sysfunc(DoSubL(%str(
 options nonotes nosource ;                          
 options ls=max ps=max locale=en_US ;                
 /* temporary redirect log */                        
 filename _stinit_ TEMP ;                            
 proc printto log = _stinit_ ; run ;                 
 /* print out setinit */                             
 proc setinit ; run ;                                
 proc printto ; run ;                                
 options ps=min ;                                    
 data _null_ ;                                       
   /* loadup checklist of required SAS components */ 
   if _n_ = 1 then                                   
     do ;                                            
       length req $ 256 ;                            
       declare hash R() ;                            
       _N_ = R.defineKey("req") ;                    
       _N_ = R.defineDone() ;                        
       declare hiter iR("R") ;                       
         do req = %bquote(
"BASE SAS SOFTWARE"
) ; 
          _N_ = R.add(key:req,data:req) ;            
         end ;                                       
     end ;                                           
                                                     
   /* read in output from proc setinit */            
   infile _stinit_ end=eof ;                         
   input ;                                           
                                                     
   /* if component is in setinit remove it from checklist */ 
   if _infile_ =: "---" then                         
     do ;                                            
       req = upcase(substr(_infile_, 4, 64)) ;       
       if R.find(key:req) = 0 then                   
         do ;                                        
           _N_ = R.remove() ;                        
         end ;                                       
     end ;                                           
                                                     
   /* if checklist is not null rise error */         
   if eof and R.num_items > 0 then                   
     do ;                                            
       put "WARNING- ###########################################" ; 
       put "WARNING:  The following SAS components are missing! " ; 
       call symputX("packageRequiredErrors", 0, "L") ;              
       do while(iR.next() = 0) ;                                    
         put "WARNING-   " req ;                                    
       end ;                                                        
       put "WARNING:  The package may NOT WORK as expected      " ; 
       put "WARNING:  or even result with ERRORS!               " ; 
       put "WARNING- ###########################################" ; 
       put ;                                         
     end ;                                           
 run ;                                               
 filename _stinit_ clear ;                           
 options notes source ;                              
 )))*;                                               
 %let temp_noNotes_etc=%sysfunc(getoption(NOTES));
 options noNotes;
 data _null_;                                                     
  if 1 = symgetn("packageRequiredErrors") then                    
    do;                                                           
      put "ERROR: Loading package &packageName. will be aborted!";
      put "ERROR- Required components are missing.";              
      put "ERROR- *** STOP ***";                                  
      call symputX("packageRequiredErrors",
     'options ls = &ls_tmp. ps = &ps_tmp. 
       &notes_tmp. &source_tmp. msglevel=&msglevel_tmp. 
       &stimer_tmp. &fullstimer_tmp. ;
       data _null_;abort;run;', "L");              
    end;                                            
  else                                              
    call symputX("packageRequiredErrors", " ", "L");
 run;                                               
 &packageRequiredErrors.                            
 options &temp_noNotes_etc.;                        
 
%if (%str(*)=%superq(cherryPick)) or (definexml in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "definexml.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(definexml)=1, NOTE# Macro definexml exist. It will be overwritten by the macro from the sas_definer package, ));
  %include PADAB352(_06_macro.definexml.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (definexml_attributes_for in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "definexml_attributes_for.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(definexml_attributes_for)=1, NOTE# Macro definexml_attributes_for exist. It will be overwritten by the macro from the sas_definer package, ));
  %include PADAB352(_06_macro.definexml_attributes_for.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (definexml_quote_xml in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "definexml_quote_xml.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(definexml_quote_xml)=1, NOTE# Macro definexml_quote_xml exist. It will be overwritten by the macro from the sas_definer package, ));
  %include PADAB352(_06_macro.definexml_quote_xml.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (spec2meta in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "spec2meta.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(spec2meta)=1, NOTE# Macro spec2meta exist. It will be overwritten by the macro from the sas_definer package, ));
  %include PADAB352(_06_macro.spec2meta.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (spec2xml in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "spec2xml.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(spec2xml)=1, NOTE# Macro spec2xml exist. It will be overwritten by the macro from the sas_definer package, ));
  %include PADAB352(_06_macro.spec2xml.sas) / nosource2;
%end; 

data _null_;                                   
  call symputX("cherryPick_CASLUDF",  0, "L"); 
run;                                           
data _null_;                                   
length CASLUDF $ 32767;                        
dtCASLudf = datetime();                        
CASLUDF =                                      
    '%macro sas_definerCASLudf('         
 !! "list=1,depList="                          
 !! ')/ des = ''CASL User Defined Functions loader for sas_definer package'';'
 !! '  %if HELP = %superq(list) %then                               '
 !! '    %do;                                                       '
 !! '      %put ****************************************************************************;'
 !! '      %put This is help for the `sas_definerCASLudf` macro;'
 !! '      %put Parameters (optional) are the following:;'
 !! '      %put - `list` indicates if the list of loaded CASL UDFs should be displayed,;'
 !! '      %put %str(  )when set to the value of `1` (the default) runs `FUNCTIONLIST USER%str(;)`,;'
 !! '      %put %str(  )when set to the value of `HELP` (upcase letters!) displays this help message.;'
 !! '      %put - `depList` [technical] contains the list of dependencies required by the package.;'
 !! '      %put %str(  )for _this_ instance of the macro the default value is: `.;'
 !! '      %put The macro generated: ' !! put(dtCASLudf, E8601DT19.-L) !! ";"
 !! '      %put with the SAS Packages Framework version 20260727.;'
 !! '      %put ****************************************************************************;'
 !! '    %GOTO theEndOfTheMacro;'
 !! '    %end;'
 !! '  %if %superq(depList) ne %then                                '
 !! '    %do;                                                       '
 !! '      %do i = 1 %to %sysfunc(countw(&depList.,%str( )));       '
 !! '        %let depListNm = %scan(&depList.,&i.,%str( ));         '
 !! '        %if %SYSMACEXIST(&depListNm.CASLudf) %then             '
 !! '          %do;                                                 '
 !! '            %&depListNm.CASLudf(list=0)                        '
 !! '          %end;                                                '
 !! '      %end;                                                    '
 !! '    %end;                                                      '
 !! '  %local tmp_NOTES;'                           
 !! '  %let tmp_NOTES = %sysfunc(getoption(NOTES));'
 !! "  filename PADAB352 &ZIP. '&path./sas_definer.&zip.';"
 !! "  options nonotes;"                      
 !! '  filename PADAB352 clear;'    
 !! '  options &tmp_NOTES.;'                
 !! '   %if 1 = %superq(list) %then '       
 !! '     %do; '                            
 !! "       FUNCTIONLIST USER;"               
 !! "       run;"                             
 !! '     %end; '                           
 !! '%theEndOfTheMacro: %mend;';            
run;

data _null_;
run;
data _null_;
run;
%if (%str(*)=%superq(cherryPick)) %then %do;
proc fcmp outlib = work.sas_definerfcmp.packagemeta ; 
 function sas_definerMETA(meta $) $ 32767;
  m = char(upcase(meta),1);
   if m = 'V' then return(strip("0.1.0"));
   if m = 'D' then return(strip("2026-10-21T09:43:00"));
   if m = 'A' then return(strip("Ryo Nakaya (nakaya.ryou@gmail.com)"));
   if m = 'M' then return(strip("PharmaForest"));
   if m = 'T' then return(strip("Create CDISC Define-XML"));
   if m = 'E' then return(strip("UTF8"));
   if m = 'L' then return(strip("2026-10-21T09:43:00"));
   if m = 'S' then return(strip("""BASE SAS SOFTWARE"""));
  return(" ");
 endfunc;
quit;
%sysfunc(ifc(0<
  %sysfunc(findw((%sysfunc(getoption(cmplib)))
                ,work.sas_definerfcmp,"'( )'",RIO))
,,%str(options APPEND=(cmplib = work.sas_definerfcmp);)
))
%macro sas_definerMETA(meta)/parmbuff;
%if %superq(meta) = %then %return;
%do;%qsysfunc(strip(%qsysfunc(sas_definerMETA&syspbuff.)))%end;
%mend;


%end;
%put NOTE- ;
%put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));

%if (%str(*)=%superq(cherryPick)) %then %do; 
 %let temp_noNotes_etc=%sysfunc(getoption(NOTES));
 options noNotes;
 data _null_ ;                                                                                              
  length SYSloadedPackages stringPCKG $ 32767;                                                              
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                           
    do;                                                                                                     
      do until(EOF);                                                                                        
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;                    
        substr(SYSloadedPackages, 1+offset, 200) = value;                                                   
      end;                                                                                                  
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");                    
      indexPCKG = INDEX(lowcase(SYSloadedPackages), '#sas_definer(');                  
      if indexPCKG = 0 then                                                                                 
         do;                                                                                                
          SYSloadedPackages = catx('#', SYSloadedPackages, 'sas_definer(0.1.0)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
      else                                                                                                  
         do;                                                                                                
          stringPCKG = kscanx(substr(SYSloadedPackages, indexPCKG+1), 1, '#');                              
          SYSloadedPackages = compbl(tranwrd(SYSloadedPackages, strip(stringPCKG), "#"));                   
          SYSloadedPackages = catx('#', SYSloadedPackages, 'sas_definer(0.1.0)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
    end;                                                                                                    
  else                                                                                                      
    do;                                                                                                     
      call symputX('SYSloadedPackages', 'sas_definer(0.1.0)', 'G');                            
      put / 'INFO: [SYSLOADEDPACKAGES] sas_definer(0.1.0)';                                     
    end;                                                                                                    
  stop;                                                                                                     
 run;                                                                                                       
 options &temp_noNotes_etc.;
%end; 

options NOTES;
%put NOTE- ;
%put NOTE: Loading package sas_definer, version 0.1.0, license MIT;
%put NOTE- *** END ***;

options &temp_noNotes_etc.;
%symdel temp_noNotes_etc / noWarn;
/* load.sas end */

